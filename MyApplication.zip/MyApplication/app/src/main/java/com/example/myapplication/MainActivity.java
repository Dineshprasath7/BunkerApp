package com.example.myapplication;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Main activity.
 */
public class MainActivity extends AppCompatActivity {

    private static final String LOGIN_URL = "https://ecampus.psgtech.ac.in/studzone2/";
    private static final String DATA_URL = "https://ecampus.psgtech.ac.in/studzone2/AttWfPercView.aspx";
    private EditText usernameEditText, passwordEditText;
    private Button fetchDataButton;
    private TableLayout bunkableClassesTable;
    private List<String[]> bunkableClasses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Bunker App");

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        fetchDataButton = findViewById(R.id.fetchDataButton);
        bunkableClassesTable = findViewById(R.id.bunkableClassesTable);

        fetchDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new FetchAttendanceDataTask().execute();
            }
        });
    }

    private class FetchAttendanceDataTask extends AsyncTask<Void, Void, List<String[]>> {
        @Override
        protected List<String[]> doInBackground(Void... voids) {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            List<String[]> attendanceDataList = new ArrayList<>();

            try {
                Connection.Response initialResponse = Jsoup.connect(LOGIN_URL).method(Connection.Method.GET).execute();
                Document initialDoc = initialResponse.parse();

                String viewstate = initialDoc.select("#__VIEWSTATE").attr("value");
                String eventvalidation = initialDoc.select("#__EVENTVALIDATION").attr("value");

                Connection.Response loginResponse = Jsoup.connect(LOGIN_URL)
                        .data("__VIEWSTATE", viewstate)
                        .data("__EVENTVALIDATION", eventvalidation)
                        .data("txtusercheck", username)
                        .data("txtpwdcheck", password)
                        .data("abcd3", "Login")
                        .method(Connection.Method.POST)
                        .execute();

                if (loginResponse.body().contains("Home")) {
                    Document dataDoc = Jsoup.connect(DATA_URL).cookies(loginResponse.cookies()).get();
                    Element table = dataDoc.select("#PDGcourpercView").first();

                    if (table != null) {
                        Elements rows = table.select("tr");
                        for (Element row : rows.subList(1, rows.size())) { // Skip header row
                            Elements columns = row.select("td");
                            String courseCode = columns.get(0).text();
                            String totalHours = columns.get(1).text();
                            String totalPresent = columns.get(4).text();
                            String currentPercentage = columns.get(5).text();
                            attendanceDataList.add(new String[]{courseCode, totalHours, totalPresent, currentPercentage});
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            bunkableClasses = calculateBunkableClasses(attendanceDataList);
            return bunkableClasses;
        }

        @Override
        protected void onPostExecute(List<String[]> bunkableClasses) {
            super.onPostExecute(bunkableClasses);
            displayBunkableClasses();
        }

        private List<String[]> calculateBunkableClasses(List<String[]> attendanceData) {
            List<String[]> bunkableClasses = new ArrayList<>();

            for (String[] courseData : attendanceData) {
                String courseCode = courseData[0];
                int totalHours = Integer.parseInt(courseData[1]);
                int totalPresent = Integer.parseInt(courseData[2]);
                int currentPercentage = Integer.parseInt(courseData[3]);

                int bunkable = totalPresent - (totalHours * 75 / 100);
                bunkableClasses.add(new String[]{courseCode, String.valueOf(totalHours), String.valueOf(totalPresent), String.valueOf(currentPercentage), String.valueOf(bunkable)});
            }

            return bunkableClasses;
        }

        private void displayBunkableClasses() {
            for (String[] bunkableClass : bunkableClasses) {
                TableRow row = new TableRow(MainActivity.this);
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                TextView courseCodeTextView = new TextView(MainActivity.this);
                courseCodeTextView.setText(bunkableClass[0]);
                row.addView(courseCodeTextView);

                TextView totalHoursTextView = new TextView(MainActivity.this);
                totalHoursTextView.setText(bunkableClass[1]);
                row.addView(totalHoursTextView);

                TextView totalPresentTextView = new TextView(MainActivity.this);
                totalPresentTextView.setText(bunkableClass[2]);
                row.addView(totalPresentTextView);

                TextView currentPercentageTextView = new TextView(MainActivity.this);
                currentPercentageTextView.setText(bunkableClass[3]);
                row.addView(currentPercentageTextView);

                TextView bunkableClassesTextView = new TextView(MainActivity.this);
                bunkableClassesTextView.setText(bunkableClass[4]);
                row.addView(bunkableClassesTextView);
                row.setBackgroundColor(getResources().getColor(R.color.table));
                courseCodeTextView.setTextColor(getResources().getColor(R.color.black));
                totalHoursTextView.setTextColor(getResources().getColor(R.color.black));
                totalPresentTextView.setTextColor(getResources().getColor(R.color.black));
                currentPercentageTextView.setTextColor(getResources().getColor(R.color.black));
                bunkableClassesTextView.setTextColor(getResources().getColor(R.color.black));
                courseCodeTextView.setPadding(3, 3, 3, 3);
                totalHoursTextView.setPadding(3, 3, 3, 3);
                totalPresentTextView.setPadding(0, 3, 0, 3);
                currentPercentageTextView.setPadding(0, 3, 0, 3);
                bunkableClassesTextView.setPadding(0, 3, 0, 3);
                bunkableClassesTable.addView(row);
            }
        }
    }
}

